from data import kontak_list

def cari_kontak():
    nama_dicari = input("Masukkan nama yang dicari: ")
    for k in kontak_list:
        if k['nama'].lower() == nama_dicari.lower():
            print(f"Nama: {k['nama']}\nTelepon: {k['telepon']}\nEmail: {k['email']}\nAlamat: {k['alamat']}")
            return
    print("Kontak tidak ditemukan.")