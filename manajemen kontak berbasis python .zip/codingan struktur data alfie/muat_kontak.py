from data import kontak_list
import csv

def muat_kontak():
    try:
        with open("kontak.csv", mode="r") as file:
            reader = csv.DictReader(file)
            for row in reader:
                kontak_list.append(row)
    except FileNotFoundError:
        pass
