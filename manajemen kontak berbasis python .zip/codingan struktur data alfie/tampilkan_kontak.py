from data import kontak_list
def tampilkan_kontak():
    if not kontak_list:
        print("Belum ada kontak.")
        return
    print("\n{:<5} {:<20} {:<15} {:<25} {:<30}".format("No", "Nama", "Telepon", "Email", "Alamat"))
    print("="*95)
    for i, k in enumerate(kontak_list, 1):
        print("{:<5} {:<20} {:<15} {:<25} {:<30}".format(i, k['nama'], k['telepon'], k['email'], k['alamat']))
