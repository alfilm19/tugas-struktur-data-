from data import kontak_list,undo_stack
from tampilkan_kontak import tampilkan_kontak
from simpan_kontak import simpan_kontak

def edit_kontak():
    tampilkan_kontak()
    try:
        idx = int(input("Masukkan nomor kontak yang ingin diedit: ")) - 1
        if 0 <= idx < len(kontak_list):
            kontak_lama = kontak_list[idx].copy()
            kontak_list[idx]['nama'] = input("Nama baru: ")
            kontak_list[idx]['telepon'] = input("Telepon baru: ")
            kontak_list[idx]['email'] = input("Email baru: ")
            kontak_list[idx]['alamat'] = input("Alamat baru: ")
            undo_stack.append(("edit", idx, kontak_lama))
            simpan_kontak()
            print("Kontak berhasil diperbarui.")
        else:
            print("Nomor kontak tidak valid.")
    except ValueError:
        print("Input tidak valid.")
