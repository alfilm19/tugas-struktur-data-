from data import undo_stack,kontak_list
from simpan_kontak import simpan_kontak

def undo():
    if not undo_stack:
        print("Tidak ada aksi yang bisa di-undo.")
        return
    aksi = undo_stack.pop()
    if aksi[0] == "hapus":
        kontak_list.remove(aksi[1])
        print("Undo: Kontak terakhir dihapus.")
    elif aksi[0] == "tambah":
        kontak_list.append(aksi[1])
        print("Undo: Kontak yang dihapus dikembalikan.")
    elif aksi[0] == "edit":
        kontak_list[aksi[1]] = aksi[2]
        print("Undo: Perubahan kontak dikembalikan.")
    simpan_kontak()
