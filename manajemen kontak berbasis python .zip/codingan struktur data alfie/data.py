kontak_list = []          
undo_stack = []   