from data import kontak_list,undo_stack
from simpan_kontak import simpan_kontak
def tambah_kontak():
    nama = input("Nama: ")
    telepon = input("Nomor Telepon: ")
    email = input("Email: ")
    alamat = input("Alamat: ")
    kontak = {"nama": nama, "telepon": telepon, "email": email, "alamat": alamat}
    kontak_list.append(kontak)
    undo_stack.append(("hapus", kontak))
    simpan_kontak()
    print("Kontak berhasil ditambahkan.")