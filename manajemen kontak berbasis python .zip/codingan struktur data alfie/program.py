from tambah_kontak import tambah_kontak
from tampilkan_kontak import tampilkan_kontak
from cari_kontak import cari_kontak
from edit_kontak import edit_kontak
from hapus_kontak import hapus_kontak
from undo import undo
from muat_kontak import muat_kontak


def menu():
    muat_kontak()  # Muat data kontak dari CSV saat program dijalankan
    while True:
        print("\n=== Menu Manajemen Kontak ===")
        print("1. Tambah Kontak")
        print("2. Tampilkan Kontak")
        print("3. Cari Kontak")
        print("4. Edit Kontak")
        print("5. Hapus Kontak")
        print("6. Undo Aksi Terakhir")
        print("7. Keluar")

        pilihan = input("Pilih menu (1-7): ")

        if pilihan == '1':
            tambah_kontak()
        elif pilihan == '2':
            tampilkan_kontak()
        elif pilihan == '3':
            cari_kontak()
        elif pilihan == '4':
            edit_kontak()
        elif pilihan == '5':
            hapus_kontak()
        elif pilihan == '6':
            undo()
        elif pilihan == '7':
            print("Terima kasih. Program selesai.")
            break
        else:
            print("Pilihan tidak valid. Silakan pilih angka 1-7.")


if __name__ == "__main__":
    menu()
