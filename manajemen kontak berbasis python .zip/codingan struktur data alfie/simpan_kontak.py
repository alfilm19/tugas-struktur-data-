from data import kontak_list
import csv
def simpan_kontak():
    with open("kontak.csv", mode="w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=["nama", "telepon", "email", "alamat"])
        writer.writeheader()
        writer.writerows(kontak_list)