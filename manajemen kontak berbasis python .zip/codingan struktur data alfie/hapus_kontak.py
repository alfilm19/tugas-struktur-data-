from data import kontak_list,undo_stack
from tampilkan_kontak import tampilkan_kontak
from simpan_kontak import simpan_kontak

def hapus_kontak():
    tampilkan_kontak()
    try:
        idx = int(input("Masukkan nomor kontak yang ingin dihapus: ")) - 1
        if 0 <= idx < len(kontak_list):
            kontak = kontak_list.pop(idx)
            undo_stack.append(("tambah", kontak))
            simpan_kontak()
            print("Kontak berhasil dihapus.")
        else:
            print("Nomor tidak ditemukan.")
    except ValueError:
        print("Input tidak valid.")
